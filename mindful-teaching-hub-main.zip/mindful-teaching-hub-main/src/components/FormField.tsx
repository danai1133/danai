
import { HTMLInputTypeAttribute } from "react";
import { cn } from "@/lib/utils";

interface FormFieldProps {
  label: string;
  name: string;
  type?: HTMLInputTypeAttribute;
  value?: string | number;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  required?: boolean;
  placeholder?: string;
  className?: string;
  children?: React.ReactNode;
  as?: "input" | "select" | "textarea";
  min?: string | number; // Added min property for number inputs
}

export const FormField = ({
  label,
  name,
  type = "text",
  value,
  onChange,
  required = false,
  placeholder,
  className,
  children,
  as = "input",
  min // Add min to destructured props
}: FormFieldProps) => {
  return (
    <div className={cn("form-group", className)}>
      <label htmlFor={name} className="form-label">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      
      {as === "input" && (
        <input
          type={type}
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          required={required}
          placeholder={placeholder}
          min={min} // Pass min to the input element
          className="form-input"
        />
      )}
      
      {as === "select" && (
        <select
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          required={required}
          className="form-select"
        >
          {children}
        </select>
      )}
      
      {as === "textarea" && (
        <textarea
          id={name}
          name={name}
          value={value}
          onChange={onChange as (e: React.ChangeEvent<HTMLTextAreaElement>) => void}
          required={required}
          placeholder={placeholder}
          className="form-textarea"
        />
      )}
    </div>
  );
};

export default FormField;
