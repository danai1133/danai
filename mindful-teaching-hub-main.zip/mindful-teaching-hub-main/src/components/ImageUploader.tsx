
import { useState, useRef } from 'react';
import { Upload, X } from 'lucide-react';

interface ImageUploaderProps {
  onChange: (files: File[]) => void;
  maxImages?: number;
  value: File[];
}

const ImageUploader = ({ onChange, maxImages = 4, value }: ImageUploaderProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList) return;

    const newFiles = Array.from(fileList);
    
    // Limit to max number of images
    const totalFiles = [...value, ...newFiles];
    const filesToAdd = totalFiles.slice(0, maxImages);
    
    onChange(filesToAdd);
    
    // Reset the input to allow selecting the same file again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveImage = (index: number) => {
    const newFiles = [...value];
    newFiles.splice(index, 1);
    onChange(newFiles);
  };

  const renderPreview = () => {
    return (
      <div className="image-preview-grid">
        {value.map((file, index) => (
          <div key={index} className="image-preview-item">
            <img 
              src={URL.createObjectURL(file)} 
              alt={`Preview ${index + 1}`}
            />
            <button
              type="button"
              onClick={() => handleRemoveImage(index)}
              className="remove-image-btn"
            >
              <X size={16} />
            </button>
          </div>
        ))}
        
        {value.length < maxImages && (
          <div
            className="image-upload-container flex flex-col items-center justify-center min-h-[160px]"
            onClick={handleClick}
          >
            <Upload size={24} className="mb-2 text-gray-500" />
            <p className="text-sm text-gray-500">
              คลิกเพื่ออัปโหลดรูปภาพ
            </p>
            <p className="text-xs text-gray-400 mt-1">
              {maxImages - value.length} รูปที่เหลือ
            </p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="mt-2">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
        multiple={maxImages > 1}
      />
      
      {value.length === 0 ? (
        <div
          className="image-upload-container flex flex-col items-center justify-center py-10"
          onClick={handleClick}
        >
          <Upload size={32} className="mb-3 text-gray-500" />
          <p className="text-gray-500">คลิกเพื่ออัปโหลดรูปภาพ</p>
          <p className="text-xs text-gray-400 mt-1">
            อัปโหลดได้สูงสุด {maxImages} รูป
          </p>
        </div>
      ) : renderPreview()}
    </div>
  );
};

export default ImageUploader;
