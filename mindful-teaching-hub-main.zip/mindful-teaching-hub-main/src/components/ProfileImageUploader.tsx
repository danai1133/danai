
import { useState, useRef } from 'react';
import { Upload, UserCircle } from 'lucide-react';

interface ProfileImageUploaderProps {
  onChange: (file: File | null) => void;
  value: File | null;
}

const ProfileImageUploader = ({ onChange, value }: ProfileImageUploaderProps) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    onChange(file);
    
    // Reset the input to allow selecting the same file again
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveImage = () => {
    onChange(null);
  };

  return (
    <div className="flex flex-col items-center">
      <div 
        className="relative w-48 h-[16rem] rounded-xl overflow-hidden border-2 border-dashed border-gray-300 cursor-pointer"
        onClick={handleClick}
      >
        {value ? (
          <img
            src={URL.createObjectURL(value)}
            alt="Profile"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="flex flex-col items-center justify-center w-full h-full bg-gray-50 hover:bg-gray-100 transition-colors">
            <UserCircle size={64} className="text-gray-400 mb-2" />
            <p className="text-sm text-gray-500">คลิกเพื่ออัปโหลดรูปประจำตัว</p>
            <p className="text-xs text-gray-400 mt-1">(อัตราส่วน 9:16)</p>
          </div>
        )}
      </div>
      
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />
      
      {value && (
        <button
          type="button"
          onClick={handleRemoveImage}
          className="mt-2 text-sm text-gray-600 hover:text-red-500 transition-colors"
        >
          ลบรูปภาพ
        </button>
      )}
    </div>
  );
};

export default ProfileImageUploader;
