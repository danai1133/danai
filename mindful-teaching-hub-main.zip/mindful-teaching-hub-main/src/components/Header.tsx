
import React from 'react';

const Header = () => {
  return (
    <header className="bg-white shadow-sm py-4">
      <div className="container mx-auto flex flex-col items-center px-4">
        <img 
          src="https://img2.imgbiz.com/imgbiz/997476f0-ac56-4d47-91ba-1c2661bbc1f0-Photoroom.png" 
          alt="Logo" 
          className="w-[150px] h-auto"
        />
        <h1 className="text-2xl md:text-3xl font-medium mt-4 text-center">
          ระบบรายงานกิจกรรมการเรียนรู้
        </h1>
      </div>
    </header>
  );
};

export default Header;
