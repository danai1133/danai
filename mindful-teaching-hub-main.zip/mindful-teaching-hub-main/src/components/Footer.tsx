
import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white mt-10 py-6">
      <div className="container mx-auto px-4 text-center">
        <p className="text-sm text-gray-500">
          © 2025 ระบบรายงานกิจกรรมการเรียนรู้ : กลุ่มงานพัฒนาพระสอนศีลธรรม
        </p>
      </div>
    </footer>
  );
};

export default Footer;
