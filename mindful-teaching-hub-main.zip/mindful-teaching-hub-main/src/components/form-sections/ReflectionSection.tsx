
import React from 'react';
import FormField from '@/components/FormField';

interface ReflectionSectionProps {
  formData: {
    changeQuestion: string;
    strengthQuestion: string;
    improveQuestion: string;
    methodQuestion: string;
  };
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const ReflectionSection = ({
  formData,
  handleChange
}: ReflectionSectionProps) => {
  return (
    <section className="form-section">
      <h2 className="text-xl font-medium mb-4 pb-2 border-b">การสะท้อนคิดเกี่ยวกับการสอน</h2>
      
      <div className="space-y-4">
        <FormField 
          label="๑. การจัดการเรียนการสอนของท่านในปีการศึกษาที่ผ่านมา สร้างการเปลี่ยนเเปลงพฤติกรรมด้านศีลธรรม จริยธรรม และมารยาทชาวพุทธของนักเรียนได้อย่างชัดเจน เป็นรูปธรรมในเรื่องใดบ้าง?" 
          name="changeQuestion" 
          as="textarea"
          value={formData.changeQuestion}
          onChange={handleChange}
          required
        />
        
        <FormField 
          label="๒. สิ่งที่ท่านทำได้ดีในการจัดการเรียนการสอนในปีการศึกษาที่ผ่านมา คือ เรื่องใดบ้าง? เพราะอะไร?" 
          name="strengthQuestion" 
          as="textarea"
          value={formData.strengthQuestion}
          onChange={handleChange}
          required
        />
        
        <FormField 
          label="๓. สิ่งที่ท่านควรปรับปรุงแก้ไขตนเองในการจัดการเรียนการสอนในปีการศึกษาที่ผ่านมา คือ เรื่องใดบ้าง? เพราะอะไร?" 
          name="improveQuestion" 
          as="textarea"
          value={formData.improveQuestion}
          onChange={handleChange}
          required
        />
        
        <FormField 
          label="๔. วิธีการที่ท่านใช้ในการปรับปรุงการจัดการเรียนการสอนของท่านเอง เพื่อให้มีประสิทธิภาพมากยิ่งขึ้น ควรทำอย่างไร?" 
          name="methodQuestion" 
          as="textarea"
          value={formData.methodQuestion}
          onChange={handleChange}
          required
        />
      </div>
    </section>
  );
};

export default ReflectionSection;
