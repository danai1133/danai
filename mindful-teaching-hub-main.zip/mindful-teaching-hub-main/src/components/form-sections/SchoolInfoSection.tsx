
import React from 'react';
import FormField from '@/components/FormField';
import { thailandProvinces, campusList } from '@/lib/provinces';

interface SchoolInfoSectionProps {
  formData: {
    school: string;
    subDistrict: string;
    district: string;
    province: string;
    campus: string;
  };
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const SchoolInfoSection = ({
  formData,
  handleChange
}: SchoolInfoSectionProps) => {
  return (
    <section className="form-section">
      <h2 className="text-xl font-medium mb-4 pb-2 border-b">ข้อมูลโรงเรียนและศูนย์</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <FormField 
            label="โรงเรียนที่ปฏิบัติการสอน" 
            name="school" 
            value={formData.school}
            onChange={handleChange}
            required
          />
          
          <FormField 
            label="ตำบล" 
            name="subDistrict" 
            value={formData.subDistrict}
            onChange={handleChange}
            required
          />
          
          <FormField 
            label="อำเภอ" 
            name="district" 
            value={formData.district}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="space-y-4">
          <FormField 
            label="จังหวัด" 
            name="province" 
            as="select"
            value={formData.province}
            onChange={handleChange}
            required
          >
            <option value="">-- เลือกจังหวัด --</option>
            {thailandProvinces.map(province => (
              <option key={province} value={province}>
                {province}
              </option>
            ))}
          </FormField>
          
          <FormField 
            label="สังกัดศูนย์อำนวยการ" 
            name="campus" 
            as="select"
            value={formData.campus}
            onChange={handleChange}
            required
          >
            <option value="">-- เลือกศูนย์อำนวยการ --</option>
            {campusList.map(campus => (
              <option key={campus} value={campus}>
                {campus}
              </option>
            ))}
          </FormField>
        </div>
      </div>
    </section>
  );
};

export default SchoolInfoSection;
