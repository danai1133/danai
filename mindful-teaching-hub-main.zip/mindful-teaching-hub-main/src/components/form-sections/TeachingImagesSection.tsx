
import React from 'react';
import ImageUploader from '@/components/ImageUploader';

interface TeachingImagesSectionProps {
  teachingImages: File[];
  setTeachingImages: (files: File[]) => void;
}

const TeachingImagesSection = ({
  teachingImages,
  setTeachingImages
}: TeachingImagesSectionProps) => {
  return (
    <section className="form-section">
      <h2 className="text-xl font-medium mb-4 pb-2 border-b">ภาพการเรียนการสอน</h2>
      
      <p className="text-gray-600 mb-4">
        อัพโหลดภาพการสอน 4 ภาพ (ขนาด 16:10 แนะนำ)
      </p>
      
      <ImageUploader 
        value={teachingImages} 
        onChange={setTeachingImages} 
        maxImages={4}
      />
    </section>
  );
};

export default TeachingImagesSection;
