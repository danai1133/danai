
import React from 'react';
import FormField from '@/components/FormField';
import ProfileImageUploader from '@/components/ProfileImageUploader';

interface PersonalInfoSectionProps {
  formData: {
    idCard: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
  };
  profileImage: File | null;
  setProfileImage: (file: File | null) => void;
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const PersonalInfoSection = ({
  formData,
  profileImage,
  setProfileImage,
  handleChange
}: PersonalInfoSectionProps) => {
  return (
    <section className="form-section">
      <h2 className="text-xl font-medium mb-4 pb-2 border-b">ข้อมูลส่วนตัว</h2>
      
      <div className="grid md:grid-cols-[1fr_3fr] gap-6">
        <div className="flex justify-center">
          <ProfileImageUploader 
            value={profileImage} 
            onChange={setProfileImage} 
          />
        </div>
        
        <div className="space-y-4">
          <FormField 
            label="เลขบัตรประชาชน" 
            name="idCard" 
            value={formData.idCard}
            onChange={handleChange}
            required
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField 
              label="ชื่อ/ฉายา" 
              name="firstName" 
              value={formData.firstName}
              onChange={handleChange}
              required
            />
            
            <FormField 
              label="นามสกุล" 
              name="lastName" 
              value={formData.lastName}
              onChange={handleChange}
              required
            />
          </div>
          
          <FormField 
            label="เบอร์โทรที่ติดต่อท่านได้" 
            name="phoneNumber" 
            type="tel"
            value={formData.phoneNumber}
            onChange={handleChange}
            required
          />
        </div>
      </div>
    </section>
  );
};

export default PersonalInfoSection;
