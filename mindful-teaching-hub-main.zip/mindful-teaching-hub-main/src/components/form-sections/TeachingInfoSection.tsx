
import React from 'react';
import FormField from '@/components/FormField';
import { classList, curriculumTypes } from '@/lib/provinces';

interface TeachingInfoSectionProps {
  formData: {
    teachingDate: string;
    teachingFrequency: string;
    classLevel: string;
    studentCount: string;
    mentorName: string;
    curriculumType: string;
    teachingContent: string;
  };
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const TeachingInfoSection = ({
  formData,
  handleChange
}: TeachingInfoSectionProps) => {
  return (
    <section className="form-section">
      <h2 className="text-xl font-medium mb-4 pb-2 border-b">ข้อมูลการปฏิบัติการสอน</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <FormField 
            label="วันที่ปฏิบัติการสอน" 
            name="teachingDate" 
            type="date"
            value={formData.teachingDate}
            onChange={handleChange}
            required
          />
          
          <FormField 
            label="ปฏิบัติการสอนสัปดาห์ละ (จำนวนวัน)" 
            name="teachingFrequency" 
            type="number"
            min="1"
            value={formData.teachingFrequency}
            onChange={handleChange}
            required
          />
          
          <FormField 
            label="ระดับชั้นที่ท่านปฏิบัติการสอน ณ ปัจจุบัน" 
            name="classLevel" 
            as="select"
            value={formData.classLevel}
            onChange={handleChange}
            required
          >
            <option value="">-- เลือกระดับชั้น --</option>
            {classList.map(classLevel => (
              <option key={classLevel} value={classLevel}>
                {classLevel}
              </option>
            ))}
          </FormField>
        </div>
        
        <div className="space-y-4">
          <FormField 
            label="จำนวนนักเรียน" 
            name="studentCount" 
            type="number"
            min="1"
            value={formData.studentCount}
            onChange={handleChange}
            required
          />
          
          <FormField 
            label="ชื่อครูพี่เลี้ยง" 
            name="mentorName" 
            value={formData.mentorName}
            onChange={handleChange}
            required
          />
          
          <FormField 
            label="เนื้อหาหรือหลักสูตรที่ท่านใช้สำหรับการจัดการเรียนการสอนกับนักเรียน" 
            name="curriculumType" 
            as="select"
            value={formData.curriculumType}
            onChange={handleChange}
            required
          >
            <option value="">-- เลือกหลักสูตร --</option>
            {curriculumTypes.map(type => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </FormField>
        </div>
      </div>
      
      <div className="mt-4">
        <FormField 
          label="เนื้อหากิจกรรมที่สอน" 
          name="teachingContent" 
          as="textarea"
          value={formData.teachingContent}
          onChange={handleChange}
          required
        />
      </div>
    </section>
  );
};

export default TeachingInfoSection;
