
import React, { useState, useRef } from 'react';
import { convertToBase64, generateFilename } from '@/lib/fileUtils';
import PersonalInfoSection from './form-sections/PersonalInfoSection';
import SchoolInfoSection from './form-sections/SchoolInfoSection';
import TeachingInfoSection from './form-sections/TeachingInfoSection';
import ReflectionSection from './form-sections/ReflectionSection';
import TeachingImagesSection from './form-sections/TeachingImagesSection';
import SubmitButton from './form-sections/SubmitButton';
import SweetAlert from './SweetAlert';

const FormContainer = () => {
  const [formData, setFormData] = useState({
    idCard: '',
    firstName: '',
    lastName: '',
    school: '',
    subDistrict: '',
    district: '',
    province: '',
    campus: '',
    teachingDate: '',
    teachingFrequency: '',
    classLevel: '',
    studentCount: '',
    mentorName: '',
    curriculumType: '',
    teachingContent: '',
    changeQuestion: '',
    strengthQuestion: '',
    improveQuestion: '',
    methodQuestion: '',
    phoneNumber: ''
  });

  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [teachingImages, setTeachingImages] = useState<File[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Convert all images to base64 strings
      const profileImageBase64 = profileImage ? await convertToBase64(profileImage) : '';
      const teachingImagesBase64 = await Promise.all(
        teachingImages.map(async (file) => {
          const base64 = await convertToBase64(file);
          const filename = generateFilename(file.name);
          return {
            filename,
            mimeType: file.type,
            data: base64
          };
        })
      );

      // Prepare data for submission
      const payload = new URLSearchParams();
      
      // Add form data
      Object.entries(formData).forEach(([key, value]) => {
        payload.append(key, String(value));
      });
      
      // Add profile image
      if (profileImage) {
        const profileFilename = generateFilename(profileImage.name);
        payload.append('profileImage', JSON.stringify({
          filename: profileFilename,
          mimeType: profileImage.type,
          data: profileImageBase64
        }));
      }
      
      // Add teaching images
      payload.append('teachingImages', JSON.stringify(teachingImagesBase64));

      // Send data to Google Apps Script Web App
      const response = await fetch(
        'https://script.google.com/macros/s/AKfycbxhXYRGhlZYESdX5lBQtC_lHZbG6jsfvmXTrYEH1Smx0WD9E1KLTAnkI0DJTB3EbvKx9g/exec',
        {
          method: 'POST',
          body: payload.toString(),
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const result = await response.json();
      console.log('Success:', result);
      
      // Reset form after successful submission
      if (formRef.current) {
        formRef.current.reset();
      }
      
      setFormData({
        idCard: '',
        firstName: '',
        lastName: '',
        school: '',
        subDistrict: '',
        district: '',
        province: '',
        campus: '',
        teachingDate: '',
        teachingFrequency: '',
        classLevel: '',
        studentCount: '',
        mentorName: '',
        curriculumType: '',
        teachingContent: '',
        changeQuestion: '',
        strengthQuestion: '',
        improveQuestion: '',
        methodQuestion: '',
        phoneNumber: ''
      });
      setProfileImage(null);
      setTeachingImages([]);
      
      // Show success alert
      setShowAlert(true);
    } catch (error) {
      console.error('Error:', error);
      // Handle error
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="form-container">
      <form ref={formRef} onSubmit={handleSubmit} className="space-y-8">
        {/* Personal Information */}
        <PersonalInfoSection 
          formData={formData} 
          profileImage={profileImage} 
          setProfileImage={setProfileImage} 
          handleChange={handleChange} 
        />
        
        {/* School Information */}
        <SchoolInfoSection 
          formData={formData} 
          handleChange={handleChange} 
        />
        
        {/* Teaching Information */}
        <TeachingInfoSection 
          formData={formData} 
          handleChange={handleChange} 
        />
        
        {/* Teaching Reflection */}
        <ReflectionSection 
          formData={formData} 
          handleChange={handleChange} 
        />
        
        {/* Teaching Images */}
        <TeachingImagesSection 
          teachingImages={teachingImages} 
          setTeachingImages={setTeachingImages} 
        />
        
        {/* Submit Button */}
        <SubmitButton isSubmitting={isSubmitting} />
      </form>

      {/* Sweet Alert */}
      <SweetAlert
        type="success"
        title="✅ ส่งคำขอเรียบร้อยแล้ว"
        show={showAlert}
        onClose={() => setShowAlert(false)}
      />
    </div>
  );
};

export default FormContainer;
