
import { useState, useEffect } from 'react';
import { Check, AlertCircle, X } from 'lucide-react';

interface SweetAlertProps {
  type: 'success' | 'error' | 'info';
  title: string;
  message?: string;
  show: boolean;
  onClose: () => void;
  autoClose?: boolean;
  autoCloseTime?: number;
}

const SweetAlert = ({
  type,
  title,
  message,
  show,
  onClose,
  autoClose = true,
  autoCloseTime = 3000,
}: SweetAlertProps) => {
  const [isVisible, setIsVisible] = useState(false);
  
  useEffect(() => {
    if (show) {
      setIsVisible(true);
      
      if (autoClose) {
        const timer = setTimeout(() => {
          setIsVisible(false);
          setTimeout(onClose, 300); // Wait for fade out animation
        }, autoCloseTime);
        
        return () => clearTimeout(timer);
      }
    } else {
      setIsVisible(false);
    }
  }, [show, autoClose, autoCloseTime, onClose]);
  
  if (!show && !isVisible) return null;
  
  const getIcon = () => {
    switch (type) {
      case 'success':
        return (
          <div className="bg-green-100 rounded-full p-2 mb-4">
            <Check className="w-10 h-10 text-green-500" />
          </div>
        );
      case 'error':
        return (
          <div className="bg-red-100 rounded-full p-2 mb-4">
            <AlertCircle className="w-10 h-10 text-red-500" />
          </div>
        );
      case 'info':
        return (
          <div className="bg-blue-100 rounded-full p-2 mb-4">
            <AlertCircle className="w-10 h-10 text-blue-500" />
          </div>
        );
    }
  };

  return (
    <div 
      className={`fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50 transition-opacity duration-300 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
      onClick={onClose}
    >
      <div 
        className={`bg-white rounded-xl shadow-lg p-6 max-w-sm mx-4 text-center transform transition-all duration-300 ${isVisible ? 'scale-100' : 'scale-95'}`}
        onClick={e => e.stopPropagation()}
      >
        <button 
          className="absolute top-2 right-2 text-gray-400 hover:text-gray-600" 
          onClick={onClose}
        >
          <X size={20} />
        </button>
        
        <div className="flex flex-col items-center">
          {getIcon()}
          <h3 className="text-xl font-medium mb-2">{title}</h3>
          {message && <p className="text-gray-600">{message}</p>}
        </div>
      </div>
    </div>
  );
};

export default SweetAlert;
