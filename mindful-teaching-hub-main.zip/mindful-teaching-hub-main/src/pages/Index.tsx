
import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FormContainer from '@/components/FormContainer';

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="flex-grow">
        <FormContainer />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Index;
